import argparse
import json
import os


def generate_diff(file_path1, file_path2):
    with open(file_path1) as f1, open(file_path2) as f2:
        data1 = json.load(f1)
        data2 = json.load(f2)
        print(json.dumps(f1))
        print(json.dumps(f2))


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("first_file", type=int)
    parser.add_argument("second_file", type=int)
    parser.add_argument(
            '-f', '--format',
            metavar='FORMAT',
            type=str,
            choices=['plain', 'json'],
            help='set format of output'
    )

    args = parser.parse_args()
    path_to_file1 = args.first_file
    path_to_file2 = args.second_file
    generate_diff(path_to_file1, path_to_file2)




if __name__ == "__main__":
    main()
    generate_diff()
